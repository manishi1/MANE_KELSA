# Mane-Kelsa Android Project

This ZIP contains a ready Android Studio project generated from the uploaded Mane-Kelsa Kotlin source PDF.

## How to run

1. Open this folder in Android Studio.
2. Create a Firebase project named `ManeKelsa`.
3. Add an Android app with package name `com.manekelsa.app`.
4. Download `google-services.json` and place it in the `app/` folder.
5. Enable Firebase Realtime Database in test mode for development.
6. Enable Phone Authentication if you later implement real login.
7. Sync Gradle, then Run.

## Notes

- A small `LoginActivity` stub was added because the provided manifest referenced it.
- Missing Android resources like colors, theme, placeholder icon, and profile button wiring were added.
- The profile screen uses `demo-worker` if Firebase Auth has no logged-in user, so you can test saving data during development.
