package com.manekelsa.app

import android.location.Location
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.manekelsa.app.databinding.ItemWorkerBinding
import kotlin.math.roundToInt

class WorkerAdapter(
    private val onCallClick: (Worker) -> Unit,
    private val onRateClick: (Worker) -> Unit
) : ListAdapter<Worker, WorkerAdapter.ViewHolder>(DIFF) {
    private var userLocation: Location? = null

    fun setUserLocation(loc: Location?) {
        userLocation = loc
        notifyDataSetChanged()
    }

    inner class ViewHolder(private val b: ItemWorkerBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(worker: Worker) {
            b.tvName.text = worker.name
            b.tvSkill.text = worker.skill
            b.tvRate.text = "₹${worker.dailyRate}/day"
            b.tvArea.text = worker.area
            b.tvRating.text = if (worker.ratingCount > 0) "★ ${String.format("%.1f", worker.rating)} (${worker.ratingCount})" else "New"

            userLocation?.let { loc ->
                val wLoc = Location("").apply {
                    latitude = worker.latitude
                    longitude = worker.longitude
                }
                val dist = loc.distanceTo(wLoc).roundToInt()
                b.tvDistance.text = if (dist < 1000) "${dist}m away" else "${dist / 1000}km away"
            } ?: run { b.tvDistance.text = "" }

            b.tvAvailability.text = if (worker.isAvailable) "✅ Available today" else "❌ Not available"

            Glide.with(b.root)
                .load(worker.photoUrl)
                .placeholder(R.drawable.ic_person_placeholder)
                .circleCrop()
                .into(b.ivPhoto)

            b.btnCall.setOnClickListener { onCallClick(worker) }
            b.btnRate.setOnClickListener { onRateClick(worker) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemWorkerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Worker>() {
            override fun areItemsTheSame(a: Worker, b: Worker) = a.uid == b.uid
            override fun areContentsTheSame(a: Worker, b: Worker) = a == b
        }
    }
}
