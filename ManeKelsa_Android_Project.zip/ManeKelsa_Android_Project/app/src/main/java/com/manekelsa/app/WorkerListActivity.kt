package com.manekelsa.app

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.manekelsa.app.databinding.ActivityWorkerListBinding
import kotlinx.coroutines.launch

class WorkerListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWorkerListBinding
    private lateinit var fusedLocation: FusedLocationProviderClient
    private lateinit var adapter: WorkerAdapter
    private var userLocation: Location? = null

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) fetchLocation() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWorkerListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        setupRecyclerView()
        checkLocationPermission()
        observeWorkers()
    }

    private fun setupRecyclerView() {
        adapter = WorkerAdapter(
            onCallClick = { worker -> callWorker(worker.phone) },
            onRateClick = { worker -> FirebaseRepository.rateWorker(worker.uid) }
        )
        binding.rvWorkers.layoutManager = LinearLayoutManager(this)
        binding.rvWorkers.adapter = adapter
        binding.btnProfile.setOnClickListener {
            startActivity(android.content.Intent(this, WorkerProfileActivity::class.java))
        }
    }

    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) fetchLocation()
        else locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun fetchLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        fusedLocation.lastLocation.addOnSuccessListener { loc ->
            userLocation = loc
            adapter.setUserLocation(loc)
        }
    }

    private fun observeWorkers() {
        lifecycleScope.launch {
            FirebaseRepository.observeAvailableWorkers().collect { workers ->
                val sorted = userLocation?.let { loc ->
                    workers.sortedBy { w ->
                        val wLoc = Location("").apply {
                            latitude = w.latitude
                            longitude = w.longitude
                        }
                        loc.distanceTo(wLoc)
                    }
                } ?: workers
                adapter.submitList(sorted)
            }
        }
    }

    private fun callWorker(phone: String) {
        val intent = android.content.Intent(
            android.content.Intent.ACTION_DIAL,
            android.net.Uri.parse("tel:$phone")
        )
        startActivity(intent)
    }
}
