package com.manekelsa.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.manekelsa.app.databinding.ActivityWorkerProfileBinding

class WorkerProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWorkerProfileBinding
    private val auth = FirebaseAuth.getInstance()
    private val uid get() = auth.currentUser?.uid ?: "demo-worker"

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) saveProfile()
        else Toast.makeText(this, getString(R.string.location_required), Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWorkerProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnSave.setOnClickListener { checkAndSave() }
        binding.switchAvailable.setOnCheckedChangeListener { _, isChecked ->
            FirebaseRepository.updateAvailability(uid, isChecked)
            val msg = if (isChecked) getString(R.string.status_available) else getString(R.string.status_unavailable)
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkAndSave() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) saveProfile()
        else locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun saveProfile() {
        val fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        fusedLocation.lastLocation.addOnSuccessListener { loc ->
            val worker = Worker(
                uid = uid,
                name = binding.etName.text.toString().trim(),
                phone = binding.etPhone.text.toString().trim(),
                skill = binding.spinnerSkill.selectedItem.toString(),
                dailyRate = binding.etRate.text.toString().toIntOrNull() ?: 0,
                area = binding.etArea.text.toString().trim(),
                isAvailable = binding.switchAvailable.isChecked,
                latitude = loc?.latitude ?: 0.0,
                longitude = loc?.longitude ?: 0.0
            )
            FirebaseRepository.saveWorker(worker) { success ->
                val msg = if (success) getString(R.string.profile_saved) else getString(R.string.save_error)
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
