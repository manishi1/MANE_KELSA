package com.manekelsa.app

import com.google.firebase.database.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

object FirebaseRepository {
    private val db = FirebaseDatabase.getInstance().reference

    fun saveWorker(worker: Worker, onResult: (Boolean) -> Unit) {
        db.child("workers").child(worker.uid)
            .setValue(worker)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    fun updateAvailability(uid: String, isAvailable: Boolean) {
        if (uid.isBlank()) return
        db.child("workers").child(uid)
            .child("available")
            .setValue(isAvailable)
    }

    fun observeAvailableWorkers(): Flow<List<Worker>> = callbackFlow {
        val query = db.child("workers")
            .orderByChild("available")
            .equalTo(true)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val workers = snapshot.children.mapNotNull { it.getValue(Worker::class.java) }
                trySend(workers)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        query.addValueEventListener(listener)
        awaitClose { query.removeEventListener(listener) }
    }

    fun rateWorker(uid: String) {
        val ref = db.child("workers").child(uid)
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(data: MutableData): Transaction.Result {
                val worker = data.getValue(Worker::class.java) ?: return Transaction.success(data)
                val newCount = worker.ratingCount + 1
                val newRating = ((worker.rating * worker.ratingCount) + 5f) / newCount
                data.child("ratingCount").value = newCount
                data.child("rating").value = newRating
                return Transaction.success(data)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) = Unit
        })
    }
}
