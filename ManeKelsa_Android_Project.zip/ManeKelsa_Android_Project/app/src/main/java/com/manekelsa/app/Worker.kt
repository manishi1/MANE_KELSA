package com.manekelsa.app

data class Worker(
    val uid: String = "",
    val name: String = "",
    val phone: String = "",
    val skill: String = "",
    val photoUrl: String = "",
    val dailyRate: Int = 0,
    val area: String = "",
    val isAvailable: Boolean = false,
    val rating: Float = 0f,
    val ratingCount: Int = 0,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
) {
    constructor() : this("", "", "", "", "", 0, "", false, 0f, 0, 0.0, 0.0)
}
